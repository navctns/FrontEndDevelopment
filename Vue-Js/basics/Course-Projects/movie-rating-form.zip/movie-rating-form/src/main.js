import { createApp } from 'vue'
import App from './App.vue'
import AppButton from './components/UI/AppButton.vue';
import AppCard from './components/UI/AppCard.vue';

const app = createApp(App)
app.component('app-button', AppButton);
app.component('app-card', AppCard);

app.mount('#app')
