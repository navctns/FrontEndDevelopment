<template>
  <div>
    <header>
      <slot name="header"></slot>
    </header>
    <section>
      <slot></slot>
    </section>
    <footer>
      <slot name="footer"></slot>
    </footer>
  </div>
</template>
<style scoped="">
  div{
    padding:1em;
    /* margin: 1em 0; */
    margin: auto;
    box-shadow: 0 2px 8px rgba(0,0,0,0.26);
    border-radius: 1em;
    /* max-width: 40rem; */
    max-width: 80%;
  }
  header,footer{
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
</style>
