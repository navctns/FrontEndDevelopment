<template id="">
  <button class="btn" :class="{flat:mode === 'flat',std:mode === 'std'}">{{value}}</button>
</template>
<script type="text/javascript">
  export default{
    props:{
      mode:{
        type:String,
        default:'std',
        // required:false,
      },
      value:{
        type:String,
        required:true,
      }
    }
  }
</script>
<style media="screen" scoped>
  .btn{
    padding:1em;
    border-radius: 0.5em;
    width:10rem;
    cursor: pointer;
  }
  .std{
    background-color: #21bf73;
  }
  .flat{
    background-color: transparent;
  }
  .flat:focus,
  .flat:hover{
      background-color: #b0eacd;
  }
</style>
