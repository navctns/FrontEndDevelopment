<template>
  <ul>
    <li>
      <a href="#">Movies</a>
    </li>
    <li>
      <a href="#">Add Movie</a>
    </li>
  </ul>
</template>
