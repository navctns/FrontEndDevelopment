<template>
  <ul>
    <movie-card
      v-for="movie in movies"
      :key="movie.id"
      :title="movie.title"
      :director="movie.director"
      :writer="movie.writer"
      :imgUrl="movie.imgUrl"
    ></movie-card>
  </ul>

</template>
<script>
  import MovieCard from './MovieCard.vue';
  export default{
    components:{
      MovieCard,
    },
    inject:['movies'],
  }
</script>
<style scoped>
  ul{
    display: flex;
    /* flex-basis: 40%; */
    /* width: calc(100% * (1/4) - 10px - 1px); */

  }
</style>
