<template>
  <ul>
    <li>
      <!-- <a href="#">Movies</a> -->
      <app-button type="button" @click="setTab('movies-list')" name="button" value="Movies" :mode="selectedTab === 'movies-list'?'std':'flat'"></app-button>
    </li>
    <li>
      <!-- <a href="#">Add Movie</a> -->
      <app-button type="button" name="button" @click="setTab('movie-form')" value="Add Movie" :mode="selectedTab === 'movie-form'?'std':'flat'"></app-button>
    </li>
  </ul>
  <keep-alive>
    <component :is="selectedTab"></component>
  </keep-alive>
</template>
<script>
  import MovieForm from './MovieForm.vue';
  import MoviesList from './MoviesList.vue';
  export default{
    components:{
      MovieForm,
      MoviesList,
    },
    data(){
      return{
        selectedTab:'movies-list',
        movies:[{
          id:'snow-piercer',
          title:'Snowpiercer',
          genre:'Action/Sci-fi',
          director:'Bong Joon-ho',
          writer:'Bong Joon-ho, Kelly Masterson',
          imgUrl:'https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcQPOHIxYdTXDpbFEWC-cv-tAQ98ELcVPMGVFy0pgFoI5s7UiDNU',
          synopsis:''
        },
        {
          id:'host',
          title:'The Host',
          genre:'Horror/Action',
          director:'Bong Joon-ho',
          writer:'Bong Joon-ho',
          imgUrl:'https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcQI9-kW4DCOtKg9c5UlYw1RgDPv5v508ysKahIbG6u_hvTa2TQH',
          synopsis:'An unidentified monster appears from the Han River in Seoul, kills hundreds and also carries off Hyun-seo. When her family learns that she is being held captive, they resolve to save her.',
        },
        {
          id:'snow-piercer',
          title:'Snowpiercer',
          genre:'Action/Sci-fi',
          director:'Bong Joon-ho',
          writer:'Bong Joon-ho, Kelly Masterson',
          imgUrl:'https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcQPOHIxYdTXDpbFEWC-cv-tAQ98ELcVPMGVFy0pgFoI5s7UiDNU',
        },
        {
          id:'host',
          title:'The Host',
          genre:'Horror/Action',
          director:'Bong Joon-ho',
          writer:'Bong Joon-ho',
          imgUrl:'https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcQI9-kW4DCOtKg9c5UlYw1RgDPv5v508ysKahIbG6u_hvTa2TQH'
        },
        {
          id:'host',
          title:'The Host',
          genre:'Horror/Action',
          director:'Bong Joon-ho',
          writer:'Bong Joon-ho',
          imgUrl:'https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcQI9-kW4DCOtKg9c5UlYw1RgDPv5v508ysKahIbG6u_hvTa2TQH'
        },

      ],
      }
    },
    provide(){
      return{
        movies:this.movies,
        addMovie:this.addMovie,
      };
    },
    methods:{
      setTab(tab){
        this.selectedTab = tab;
      },
      addMovie(movieObj){
        this.movies.unshift(movieObj);
      }

  }
}
</script>
<style media="screen" scoped>
  ul{
    list-style: none;
    text-decoration: none;
    margin: auto;
    display: flex;
    gap:1em;
    align-items: center;
    justify-content: center;
  }
  li a{
    text-decoration: none;
  }

</style>
