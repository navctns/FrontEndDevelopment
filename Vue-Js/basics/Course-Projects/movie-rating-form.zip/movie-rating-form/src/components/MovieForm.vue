<template>
  <app-card>
    <form>
      <div class="form-control">
        <label for="movie-name"></label>
        <input type="text" name="movie-name">
      </div>
      <div class="form-control">
        <label for="movie-director"></label>
        <input type="text" name="movie-director">
      </div>
      <div class="form-control">
        <label for="movie-writer"></label>
        <input type="text" name="movie-writer">
      </div>
      <div class="form-control">
        <button>Save Item</button>
      </div>
    </form>
  </app-card>
</template>
