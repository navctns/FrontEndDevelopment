<template>
  <div class="main">
    <app-card>
      <template #default>
        <div>
          <h2>About</h2>

          <p>
            Like every Art form Movies are not just for watching passivly,
            Movies can be observed, analyzed on certain ways. Through that film experience can be enriched. Here you can know about
            films and refer about it
          </p>
          <h3>Source Credits</h3>
          <p>This product uses the TMDb API but is not endorsed or certified by TMDb.</p>
          <img src="https://www.themoviedb.org/assets/2/v4/logos/v2/blue_long_2-9665a76b1ae401a510ec1e0ca40ddcb3b0cfe45f1d51b77a308fea0845885648.svg" alt=""/>

          <h3>Film Movements Sources</h3>
          <ul>
            <li><a  href="https://www.empireonline.com/movies/features/movie-moments/" target="_blank">www.empireonline.com</a></li>
            <li><a  href="https://www.movementsinfilm.com/" target="_blank">www.movementsinfilm.com</a></li>
          </ul>

          <h4>German Expressionism</h4>
          <ul>
            <li><a target="_blank" href="https://books.google.ae/books?id=-5ELAQAAMAAJ&q=german+expressionism+world+of+light+and+shadow&dq=german+expressionism+world+of+light+and+shadow&hl=en&sa=X&ved=0ahUKEwjnoa_6h-LbAhWBJ8AKHbRuAIYQ6AEIJTAA">German Expressionist Cinema: The World of Light and Shadow </a>(Ian Roberts)</li>
          </ul>
          <h4>French Impressionist Cinema</h4>
            <ul>
              <li><a target="_blank" href="https://books.google.ae/books?id=97YkAQAAMAAJ&dq=french+impressionist+cinema&hl=en&sa=X&ved=0ahUKEwjio-iAieLbAhWpKcAKHQBFDykQ6AEIJTAA">French Impressionist Cinema: Film Culture, Film Theory, and Film Style </a>(David Bordwell)</li>
            </ul>
            <h4>Soviet Montage</h4>
            <ul>
              <li><a target="_blank" href="https://books.google.ae/books/about/Film_Form.html?id=5PtYOseGqLYC&redir_esc=y">Film Form: Essays in Film Theory</a>(Sergei Eisenstein, Sergei M. Eisenstein, Sergej Mihajlovič Èjzenštejn)</li>
            </ul>
            <h4>Italian Neorealism</h4>
            <ul>
              <li><a target="_blank" href="https://books.google.ae/books?id=UiCovW1K9osC&printsec=frontcover&dq=Italian+Neorealism-+Rebuilding+the+Cinematic+City&hl=en&sa=X&ved=0ahUKEwi64aDAhuLbAhVFOMAKHQZ-A1cQ6AEIJTAA#v=onepage&q=Italian%20Neorealism-%20Rebuilding%20the%20Cinematic%20City&f=false">    Italian Neorealism: Rebuilding the Cinematic City</a>(Mark Shiel)</li>
              <li><a target="_blank" href="https://books.google.ae/books?id=LR7lAgAAQBAJ&printsec=frontcover&dq=Cinema+of+Anxiety:+A+Psychoanalysis+of+Italian+Neorealism&hl=en&sa=X&ved=0ahUKEwig0vqqiOLbAhWIK8AKHV54D_oQ6AEIJTAA#v=onepage&q=Cinema%20of%20Anxiety%3A%20A%20Psychoanalysis%20of%20Italian%20Neorealism&f=false">Cinema of Anxiety: A Psychoanalysis of Italian Neorealism</a>(Vincent F. Rocchio)</li>

            </ul>
            <h4>Japanese New Wave</h4>
            <ul>
              <li>
                <a target="_blank" href="https://books.google.ae/books?id=tOJkAAAAMAAJ&q=Eros+Plus+Massacre:+An+Introduction+to+the+Japanese+New+Wave+Cinema:+Introduction+to+Japanese+New+Wave+Cinema&dq=Eros+Plus+Massacre:+An+Introduction+to+the+Japanese+New+Wave+Cinema:+Introduction+to+Japanese+New+Wave+Cinema&hl=en&sa=X&ved=0ahUKEwi_5Oeeh-LbAhWqDMAKHXVzAXEQ6AEIJTAA">Eros Plus Massacre: An Introduction to the Japanese New Wave Cinema</a>
                (David Desser)
              </li>
            </ul>
            <h4>British New Wave</h4>
            <ul>
              <li><a target="_blank" href="https://books.google.ae/books?id=TP9rBgAAQBAJ&printsec=frontcover&dq=british+new+wave+a+certain+tendency&hl=en&sa=X&ved=0ahUKEwjppN6qieLbAhVJTcAKHaNGDPEQ6AEIKDAA#v=onepage&q=british%20new%20wave%20a%20certain%20tendency&f=false">The British New Wave: A certain tendency? </a>(B. F. Taylor)</li>
            </ul>
            <h4>French New Wave</h4>
            <ul>
              <li><a target="_blank" href="https://books.google.ae/books/about/The_French_New_Wave.html?id=hLpoAAAAMAAJ&redir_esc=y">The French New Wave: A New Look</a>(Naomi Greene)</li>
              <li><a target="_blank" href="https://books.google.ae/books?id=LUWijfZ_QkMC&printsec=frontcover&dq=french+new+wave+an+artistic+school&hl=en&sa=X&ved=0ahUKEwjmz-PDh-LbAhWlLMAKHX7IBCcQ6AEIJTAA#v=onepage&q=french%20new%20wave%20an%20artistic%20school&f=false">French New Wave: An Artistic School </a>(Michel Marie, Richard Neupert)</li>
            </ul>
            <h4>Hong Kong New Wave</h4>
            <ul>
              <li><a target="_blank" href="https://books.google.ae/books?id=tezz-YTGJ00C&printsec=frontcover&dq=Hong+Kong+New+Wave+Cinema+(1978-2000)&hl=en&sa=X&ved=0ahUKEwikucyHh-LbAhVpBMAKHWM_AGAQ6AEIJTAA#v=onepage&q=Hong%20Kong%20New%20Wave%20Cinema%20(1978-2000)&f=false">Hong Kong New Wave Cinema (1978-2000)</a>(Pak Tong Cheuk)</li>
            </ul>
            <h4>Dogme 95</h4>
            <ul>
              <li><a href="http://www.dogme95.dk" target="_blank">www.dogme95.dk</a></li>
              <li><a href="https://harmony-korine.com/paper/index/i_julien.html" target="_blank">Harmony-Korine.com: Julien Donkey-Boy index</a></li>
            </ul>
            <div class="scroll-block">
              <i class="fas fa-arrow-circle-up fa-3x" @click="scrollToTop"></i>
            </div>
          </div>
      </template>
    </app-card>
  </div>



    <!-- </app-card> -->
  <!-- </section> -->


</template>
<script>
  export default{
    methods:{
      scrollToTop(){
        window.scrollTo(0,0);
      },
    }
  }
</script>

<style scoped>
  div{
    display: flex;
    flex-direction: column;
    align-items: center;
    gap:0;
    place-items:center;
    grid-gap: 1em;
    min-height: 100vh;
    /* margin: 0 0.5em; */
    padding:0;
    /* margin: auto; */
    padding: 0 2em;
    width:100%;
  }
  div img{
    display: flex;
    justify-content: center;
    width:50%;
  }
  h2,h3{
    margin:0;
    display: flex;
    justify-content: center;
 }
 ul{
   display: flex;
   flex-direction: column;
   align-items: center;
   /* text-align: left; */
   /* max-width: 90%; */
   padding:0;
   margin:0;
 }

 img{
  width:100%;
  height: auto;
 }
 a{
   color:#fafafa;
   text-decoration: none;
 }
 a:hover,
 a:focus{
   opacity: 0.7;
 }
 section{
   margin:0;
   padding: 0;
 }

 /* .scroll-block{
   display: flex;
   align-items:flex-end;
   justify-content: flex-end;
   padding:1em;
 } */
 .fa-arrow-circle-up:hover,
 .fa-arrow-circle-up:focus{
   cursor: pointer;
 }
 .main{
   margin:2em 0;
 }
 @media(max-width:768px) {
   /* h2,h3{
     font-weight: 500;
   } */
   /* p{
     font-size:0.8em;
   } */

   div img{
     width:80%;
     height:auto;
   }
   div{
     padding: 0.5em;
     width:auto;
   }
   ul li{
     display: flex;
     flex-direction: column;
     justify-content: center;
     list-style: none;
     width:90%;
   }
   li a {
     display: flex;
     justify-content: center;
   }
 }
</style>
