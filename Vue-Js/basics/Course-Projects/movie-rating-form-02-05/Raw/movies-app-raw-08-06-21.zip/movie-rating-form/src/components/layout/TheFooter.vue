<template>
  <footer>
    <h5>Film Observation<span>&copy;</span></h5>
  </footer>
</template>
<style scoped>
footer{
  background:#232323;
  display: flex;
  justify-content: center;
  align-items: flex-end;
  min-height: 20vh;
  margin:0;
}
</style>
