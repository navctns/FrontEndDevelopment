<template lang="html">
  <p>Ball Movement</p>
  <h3>Component</h3>
</template>

<script>
export default {
}
</script>

<style lang="css" scoped>
  p,h3{
    color:#fff;
  }
</style>
