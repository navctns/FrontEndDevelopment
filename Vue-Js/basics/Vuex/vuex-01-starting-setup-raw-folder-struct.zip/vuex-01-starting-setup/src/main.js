import { createApp } from 'vue';
import { createStore } from 'vuex';

import App from './App.vue';
const app = createApp(App);

//Vuex
//modules
const counterModule = {
  namespaced:true,
  state(){
    return{
      counter:0,
    };
  },
  mutations:{
    increment(state){
      state.counter++;
    },
    increase(state, payload){
      state.counter = state.counter + payload.value;
    },
  },
  actions:{
    increment(context){
      console.log(context);
      setTimeout(()=>{
        context.commit('increment');
      },2000);
    },
    increase(context, payload){
      context.commit('increase', payload);
    },
  },
  getters:{
    finalCounter(state){
      return state.counter * 2;
    },
    normalizedCounter(_, getters){
      // const finalCounter = state.counter * 3;
      const finalCounter = getters.finalCounter;
      if(finalCounter < 0){
        return 0;
      }
      if(finalCounter > 100){
        return 100;
      }
      return finalCounter;
    },
    testAuth(state){
      return state.isLoggedIn;
    }
  }
}

const store = createStore({
  modules:{
    numbers:counterModule,
  },
  state(){
    return{
      counter:0,
      isAuthenticated:false,
    };
  },
  mutations:{

    setAuth(state,payload){
      state.isAuthenticated = payload.isAuth;
    }
    // login(state){
    //   state.isAuthenticated = true;
    // },
    // logout(state){
    //   state.isAuthenticated = false;
    // }


  },
  actions:{

    login(context){
      context.commit('setAuth', {isAuth:true})
    },
    logout(context){
      context.commit('setAuth', {isAuth:false})
    }
  },
  getters:{

    isAuthenticated(state){
      return state.isAuthenticated;
    },
    // isTestAuth(){
    //   return this.$store.getters.testAuth;
    // }

  }
});

app.use(store);

app.mount('#app');
