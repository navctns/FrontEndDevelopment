<template lang="html">
  <h3>{{ finalCounter }}</h3>
</template>

<script>
import { mapGetters } from 'vuex';
export default {
  computed:{
    // counter(){
    //   // return this.$store.state.counter * 2;
    //   return this.$store.getters.finalCounter;
    // }
    ...mapGetters('numbers',['finalCounter'])
  }
}
</script>

<style lang="css" scoped>
</style>
