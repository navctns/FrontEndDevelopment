module.exports = {
  css: { extract: false }
}