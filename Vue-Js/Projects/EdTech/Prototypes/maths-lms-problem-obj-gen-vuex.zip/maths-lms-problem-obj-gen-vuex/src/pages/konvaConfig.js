export default{
        //vue-conva main canvas
    canvas:{
        width: 1200,
        height: 800
    }
}