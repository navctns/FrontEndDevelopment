export default {
    getProblemObj(state){
        //Return Current Problem Object
        return state.currProbObj;
    }
}