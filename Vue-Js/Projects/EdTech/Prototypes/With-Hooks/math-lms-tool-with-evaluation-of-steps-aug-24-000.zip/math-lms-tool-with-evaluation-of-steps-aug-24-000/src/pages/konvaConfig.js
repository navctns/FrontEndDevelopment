export default{
        //vue-conva main canvas
    canvas:{
        width: 1500,
        height: 1500
    }
}