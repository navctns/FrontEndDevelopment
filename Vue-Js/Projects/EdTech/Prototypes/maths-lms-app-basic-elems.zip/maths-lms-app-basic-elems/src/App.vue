<template>
  <problem-page></problem-page>
</template>

<script>
// import HelloWorld from './components/HelloWorld.vue'
import ProblemPage from './pages/ProblemPage.vue';
export default {
  components: {
    ProblemPage
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
