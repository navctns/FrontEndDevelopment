<template>
  <h3>Boilerplate Home</h3>
</template>
