<template>
  <div>
    <router-link to="/">Home</router-link>
    <router-link to="/about">About</router-link>
  </div>

</template>
<style scoped>
  div{
    display: flex;
    gap:1em;
    justify-content: center;
  }
</style>
