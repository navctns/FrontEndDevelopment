<template>
  <h2>Home</h2>
</template>