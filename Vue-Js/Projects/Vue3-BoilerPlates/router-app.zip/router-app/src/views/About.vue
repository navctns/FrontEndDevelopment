<template>
  <h2>About</h2>
</template>